// var category = document.getElementById('category-insight'),
// form  = document.getElementById('insight-form');
//
//
// category.addEventListener('change', function(){
//
// if(category.value == "Articles"){
//
// var html = '<div class="form-group mb30"><label class="control-label">Article Title</label><?php $display = displayErrors($error, "title");echo $display ?> <input class="form-control input-md" name="title" placeholder="Write a suitable title for your article"  type="text"></div><div class="form-group mb30"><label class="control-label">Author Name</label><?php $display = displayErrors($error, "author");echo $display ?> <input class="form-control input-md" name="author" placeholder="Enter your fullname here"  type="text">';
//   form.innerHTML = html;
// }
// if(category.value == "Resources"){
//   form.innerHTML = "Resources";
// }
//
// if(category.value == "Reports"){
// var html = '<div class="form-group mb30"><label class="control-label">Report Title</label><?php $display = displayErrors($error, "title");echo $display ?> <input class="form-control input-md" name="title" placeholder="Write a suitable title for your Report"  type="text"></div>';
//
// form.innerHTML = html;
// }
//
// }, false);
